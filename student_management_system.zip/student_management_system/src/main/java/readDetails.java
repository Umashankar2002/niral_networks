

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class readDetails
 */
@WebServlet("/readDetails")
public class readDetails extends HttpServlet 
{
	
	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet result;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		
		HttpSession session=req.getSession();
		int id=Integer.parseInt(req.getParameter("id"));
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student_management","root","Umashankar143@");
			
			String sql="select * from student where id=?";
			
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, id);
			result=pstmt.executeQuery();
			ArrayList<String> arr=new ArrayList<>();
			if(result.next())
			{
				arr.add(result.getString(1));
				arr.add(result.getLong(2)+"");
				arr.add(result.getString(3));
				arr.add(result.getString(4));
				arr.add(result.getInt(5)+"");
				arr.add(result.getString(6));
				arr.add(result.getLong(7)+"");
				
				session.setAttribute("details",arr);
				resp.sendRedirect("showDetails.jsp");
			}
			else
			{
				session.setAttribute("read","student not found");
				resp.sendRedirect("homePage.jsp");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
