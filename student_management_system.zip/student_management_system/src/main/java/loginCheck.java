import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class loginCheck
 */
@WebServlet("/loginCheck")
public class loginCheck extends HttpServlet {
	
		private Connection con;
		private PreparedStatement pstmt;
		private ResultSet result;

		@Override
		protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
		{
			
			String email=req.getParameter("email");
			String password=req.getParameter("password");
			
		
			HttpSession session=req.getSession();
			String sql="select password from admin where email=?";
			try
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student_management","root","Umashankar143@");
				
				pstmt=con.prepareStatement(sql);
				pstmt.setString(1, email);
				
				result=pstmt.executeQuery();
				if(result.next())
				{
					if(result.getString(1).equals(password))
					{
						resp.sendRedirect("homePage.jsp");
					}
					else
					{
						session.setAttribute("password", "wrong password plz check once");
						resp.sendRedirect("login.jsp");
					}
				}
				else
				{
					session.setAttribute("password", "Go and create an account");
					resp.sendRedirect("login.jsp");
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}

}
