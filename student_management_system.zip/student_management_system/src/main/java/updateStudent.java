

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class updateStudent
 */
@WebServlet("/updateStudent")
public class updateStudent extends HttpServlet {
	
	private Connection con;
	private PreparedStatement pstmt;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		HttpSession session=req.getSession();
		
		String name=req.getParameter("name");
		String password=req.getParameter("password");
		double phone=Double.parseDouble(req.getParameter("phone"));
		String email=req.getParameter("email");
		int year=Integer.parseInt(req.getParameter("year"));
		
		String fname=req.getParameter("father");
		double fphone=Double.parseDouble(req.getParameter("fatherPhone"));
		
		
		String sql="update student set name=?,phone=?,password=?,email=?,year=?,fathername=?,fatherPhone=? where id=?";
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student_management","root","Umashankar143@");
			
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1,name);
			pstmt.setDouble(2,phone);
			pstmt.setString(3, password);
			pstmt.setString(4, email);
			pstmt.setInt(5, year);
			pstmt.setString(6, fname);
			pstmt.setDouble(7, fphone);
			pstmt.setInt(8, (int)session.getAttribute("id"));
			
			int x=pstmt.executeUpdate();
			
			if(x!=0)
			{
				session.setAttribute("update", "successfully updated");
				resp.sendRedirect("homePage.jsp");
			}
			else
			{
				session.setAttribute("update", "something wrong");
				resp.sendRedirect("homePage.jsp");
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
