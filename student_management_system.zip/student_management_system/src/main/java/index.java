

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class index
 */
@WebServlet("/index")
public class index extends HttpServlet {
	
	private Connection con;
	private PreparedStatement pstmt;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		
		String mail=req.getParameter("email");
		String password=req.getParameter("password");
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student_management","root","Umashankar143@");
			
			String sql="insert into admin values(?,?)";
			
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, mail);
			pstmt.setString(2, password);
			
			pstmt.executeUpdate();
			
			resp.sendRedirect("login.jsp");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
