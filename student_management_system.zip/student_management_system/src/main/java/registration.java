

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class registration
 */
@WebServlet("/registration")
public class registration extends HttpServlet {
	
	private Connection con;
	private PreparedStatement pstmt;
	
	

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		HttpSession session=req.getSession();
		
		String name=req.getParameter("name");
		String password=req.getParameter("password");
		double phone=Double.parseDouble(req.getParameter("phone"));
		String email=req.getParameter("email");
		int year=Integer.parseInt(req.getParameter("year"));
		
		String fname=req.getParameter("father");
		double fphone=Double.parseDouble(req.getParameter("fatherPhone"));
		
		
		
		try
		{
			String sql="insert into student (name,phone,password,email,year,fathername,fatherPhone) values(?,?,?,?,?,?,?)";
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student_management","root","Umashankar143@");
			
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1,name);
			pstmt.setDouble(2,phone);
			pstmt.setString(3, password);
			pstmt.setString(4, email);
			pstmt.setInt(5, year);
			pstmt.setString(6, fname);
			pstmt.setDouble(7, fphone);
			
			int x=pstmt.executeUpdate();
			
			if(x!=0)
			{
				session.setAttribute("insert", "successfully inserted");
				resp.sendRedirect("homePage.jsp");
			}
			else
			{
				session.setAttribute("insert", "something wrong");
				resp.sendRedirect("homePage.jsp");
			}
			
		}
		catch(Exception e)
		{
			session.setAttribute("insert", "something wrong");
			resp.sendRedirect("homePage.jsp");
			
		}
	}
}
